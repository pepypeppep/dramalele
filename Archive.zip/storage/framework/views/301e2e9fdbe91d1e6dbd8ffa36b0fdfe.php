<?php $__env->startSection('content'); ?>
    <div class="search_searchWrap__4tSPy">
        <div class="search_searchBox__hxwgc">
            <div class="search_searchHeader__bL0IU">
                <span><?php echo e($totalNum); ?></span> results were found for <span><?php echo e(request('q')); ?></span>
            </div>
            <?php $__currentLoopData = $booklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="RankingsBookItem_rankingsBookWrap__Dzv8Y">
                    <div class="RankingsBookItem_imageItem1Wrap__KhEDB">
                        <a class="RankingsBookItem_bookImage__xhWCo image_imageBox__Mubn5 image_imageScaleBox__JFwzM"
                            href="<?php echo e(route('dramas.show', [$data->bookId, $data->bookNameEn])); ?>">
                            <img alt="<?php echo e($data->bookName); ?>" loading="lazy" width="150" height="200" decoding="async"
                                data-nimg="1" class="image_imageItem__IZeBT" style="color:transparent"
                                src="<?php echo e($data->coverWap); ?>">
                        </a>
                        <div class="RankingsBookItem_bookInfo__pgA5P">
                            <a class="RankingsBookItem_bookName__kmTaH"
                                href="<?php echo e(route('dramas.show', [$data->bookId, $data->bookNameEn])); ?>">
                                <span style="color: #FF375F"><?php echo e($data->bookName); ?></span>
                            </a>
                            <a class="RankingsBookItem_bookLine2__ac9BK"
                                href="<?php echo e(route('dramas.show', [$data->bookId, $data->bookNameEn])); ?>"><?php echo e($data->totalChapterNum); ?><span>Episodes</span></a>
                            <a class="RankingsBookItem_intro__oRUOH"
                                href="<?php echo e(route('dramas.show', [$data->bookId, $data->bookNameEn])); ?>"><?php echo e($data->introduction); ?></a>
                        </div>
                        <a class="RankingsBookItem_readBtn__J_9gB"
                            href="<?php echo e(route('dramas.show', [$data->bookId, $data->bookNameEn])); ?>">Watch Now</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($totalPage > 1): ?>
            <div class="paginationCom_pageContent__wspPw">
                <?php if($pageNo > 1): ?>
                    <a class="paginationCom_prevBtn__tSFZr"
                        href="/search?q=<?php echo e(request('q')); ?><?php echo e($pageNo == 2 ? '/' : '&page=' . ($pageNo - 1)); ?>">
                        <img alt="prev" loading="lazy" width="14" height="14" decoding="async"
                            class="paginationCom_prevNextIcon__ZxNjw" style="color:transparent"
                            src="<?php echo e(asset('images/next_2.png')); ?>">
                    </a>
                <?php else: ?>
                    <div class="paginationCom_prevNoMore__k9A75" style="opacity: 0.5; pointer-events: none;">
                        <img alt="prev" loading="lazy" width="14" height="14" decoding="async"
                            class="paginationCom_prevNextIcon__ZxNjw" style="color:transparent"
                            src="<?php echo e(asset('images/next_2.png')); ?>">
                    </div>
                <?php endif; ?>

                <?php if($pageNo > 3): ?>
                    <a class="paginationCom_normalLi__YFrvZ" href="/search?q=<?php echo e(request('q')); ?>">1</a>
                    <div class="paginationCom_omission__2F81x">…</div>
                <?php endif; ?>

                <?php for($i = $pageNo - 2; $i <= $pageNo + 2; $i++): ?>
                    <?php if($i >= 1 && $i <= $pages): ?>
                        <?php if($i == $pageNo): ?>
                            <div class="paginationCom_activePage__Ke4Ik"><?php echo e($i); ?></div>
                        <?php else: ?>
                            <a class="paginationCom_normalLi__YFrvZ"
                                href="/search?q=<?php echo e(request('q')); ?><?php echo e($i == 1 ? '/' : '&page=' . $i); ?>"><?php echo e($i); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if($pageNo < $pages - 2): ?>
                    <div class="paginationCom_omission__2F81x">…</div>
                    <a class="paginationCom_normalLi__YFrvZ"
                        href="/search?q=<?php echo e(request('q')); ?>&page=<?php echo e($pages); ?>"><?php echo e($pages); ?></a>
                <?php endif; ?>

                <?php if($pageNo < $pages): ?>
                    <a class="paginationCom_nextBtn__E0BGd"
                        href="/search?q=<?php echo e(request('q')); ?><?php echo e($pageNo + 1 == $pages ? '&page=' . ($pageNo + 1) : '&page=' . ($pageNo + 1)); ?>">
                        <img alt="next" loading="lazy" width="14" height="14" decoding="async"
                            class="paginationCom_prevNextIcon__ZxNjw" style="color:transparent"
                            src="<?php echo e(asset('images/next_1.png')); ?>">
                    </a>
                <?php else: ?>
                    <div class="paginationCom_nextNoMore__24x_P" style="opacity: 0.5; pointer-events: none;">
                        <img alt="next" loading="lazy" width="14" height="14" decoding="async"
                            class="paginationCom_prevNextIcon__ZxNjw" style="color:transparent"
                            src="<?php echo e(asset('images/next_1.png')); ?>">
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/092978e99d76a4da.css')); ?>" data-n-p="" />
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zasieun/code/dramalele/resources/views/search.blade.php ENDPATH**/ ?>