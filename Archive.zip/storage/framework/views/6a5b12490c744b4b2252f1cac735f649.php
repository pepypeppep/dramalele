<script type="text/template" id="skeleton-template">
    <div class="animate-pulse">
        <div class="aspect-[2/3] rounded-lg bg-gray-800"></div>
        <div class="h-3 bg-gray-700 rounded mt-2"></div>
        <div class="h-3 bg-gray-700 rounded mt-1 w-4/5"></div>
    </div>
</script>
<?php /**PATH /Users/zasieun/code/dramalele/resources/views/dramabox/partials/skeleton.blade.php ENDPATH**/ ?>