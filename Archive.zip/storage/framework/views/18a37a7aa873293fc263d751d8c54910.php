<?php
    $cover = str_replace('@w=100&h=135', '', $chapterlist[$episode - 1]->cover);
?>
<?php $__env->startSection('content'); ?>
    <main class="Video_videoWrap__HUe7w">
        <div class="Video_videoHeader__rB_Ky">
            <div class="breadcrumb_crumbsWrap__SWofi">
                <div class="breadcrumb_crumbItem__gzO8K">
                    <a href="/">Home</a><img alt=">" width="24" height="24" decoding="async" data-nimg="1"
                        class="breadcrumb_crumbIcon__F6TLQ" src="<?php echo e(asset('images/arrow-left.png')); ?>"
                        style="color: transparent;">
                </div>
                <div class="breadcrumb_crumbItem__gzO8K">
                    <a href="drama?id=41000119495&lang=en"><?php echo e($data->bookName); ?></a>
                    <img alt=">" width="24" height="24" decoding="async" data-nimg="1"
                        class="breadcrumb_crumbIcon__F6TLQ" src="<?php echo e(asset('images/arrow-left.png')); ?>"
                        style="color: transparent;">
                </div>
                <div class="breadcrumb_crumbItem__gzO8K">
                    <div class="breadcrumb_lastTxt__cdw0_">Episodes <?php echo e($episode); ?></div>
                </div>
            </div>
        </div>

        <div class="pcEpisode_videoBox__658Je">
            <div class="pcEpisode_leftVideo__qV0HP" id="videoContainers">
                <div style="background: url(<?php echo e($cover); ?>) center center / auto 100% no-repeat #1a1a1a;"
                    class="pcEpisode_videoContainerStart___u5El">
                    <img alt="Play button" loading="lazy" width="52" height="52" decoding="async" data-nimg="1"
                        class="pcEpisode_videoStart__IcAdF" style="color: transparent; cursor: pointer;"
                        src="<?php echo e(asset('images/play.png')); ?>" />
                </div>
            </div>
            <div class="pcEpisode_leftVideo__qV0HP" id="videoContainer" style="display: none;">
                <div style="background: url('<?php echo e($cover); ?>') center center / auto 100% no-repeat #1a1a1a;"
                    class="pcEpisode_videoContainer__5hYji">
                    <video id="video_pc_id" preload="false" autoplay poster="<?php echo e($cover); ?>" tabindex="-1" controls
                        disablepictureinpicture disableremoteplayback x-webkit-airplay="deny" playsinline
                        webkit-playsinline="true" x5-playsinline="true" x5-video-player-type="h5"
                        controlslist="nodownload noremoteplayback noplaybackrate">
                        <source src="<?php echo e($videoSrc); ?>" type="video/mp4" />
                    </video>
                </div>
            </div>

            <div class="RightList_rightBox__9OVp0">
                <div class="RightList_rightTop__Blgm4">
                    <span class="RightList_title__09Jv_">Episodes</span>
                    <span class="RightList_current__B8KDw">(<?php echo e($episode); ?>/<?php echo e($data->chapterCount); ?>)</span>
                </div>
                <div class="RightList_tabHeader__ZwNKK">
                    
                </div>
                <div class="RightList_tabContent__E2D_a" data-tab="1">
                    <?php $__currentLoopData = $chapterlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="RightList_linkText__86R_r" title="<?php echo e($data->bookName); ?> <?php echo e($chapter->indexStr); ?>"
                            id="<?php echo e($chapter->id . '_Episode-' . ($key + 1)); ?>"
                            href="<?php echo e(route('dramas.video', [$data->bookId, $data->bookNameEn, $chapter->id . '_Episode-' . ($key + 1)])); ?>"
                            style="display: inline-block;"><?php echo e(ltrim($chapter->indexStr, '0')); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <script>
                    document.querySelectorAll('.RightList_tabTitle__zvZRp').forEach(tab => {
                        tab.addEventListener('click', function() {
                            let tabId = this.getAttribute('data-tab');

                            document.querySelectorAll('.RightList_tabTitle__zvZRp').forEach(t => t.classList.remove(
                                'RightList_tabTitleActive__ySX78'));
                            this.classList.add('RightList_tabTitleActive__ySX78');

                            document.querySelectorAll('.RightList_tabContent__E2D_a').forEach(list => list.style
                                .display = 'none');
                            document.querySelector('.RightList_tabContent__E2D_a[data-tab="' + tabId + '"]').style
                                .display = 'block';
                        });
                    });
                </script>
            </div>
        </div>
        <div class="pcEpisode_videoInfo__PmvZz">
            <h1 class="pcEpisode_videoTitle__3jWfu"><?php echo e($data->bookName); ?><span> Episodes <?php echo e($episode); ?></span></h1>
            <div class="pcEpisode_videoStar__q1Dc0">
                <img alt="" width="24" height="24" decoding="async" data-nimg="1"
                    class="pcEpisode_imageStar__Ki_yh" src="<?php echo e(asset('images/star.png')); ?>"
                    style="color: transparent;"><span class="pcEpisode_videoScore__hUrWc"
                    id="viewseooa"><?php echo e($data->viewCount); ?></span>
            </div>
            <p class="pcEpisode_videoDesc__w9PEx"><?php echo e($data->bookName); ?> Episodes <?php echo e($episode); ?>,
                <?php echo e($data->introduction); ?></p>

            <div class="pcEpisode_tagBox__GdklB">
                <?php $__currentLoopData = $data->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class='pcEpisode_tagItem__AqYwI' href=''><?php echo e($tag); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="relatedEpisode_relatedEpisode__l_NFQ">
                <div class="relatedEpisode_relatedTitle__5tQl5">Episode List</div>
                <div class="relatedEpisode_listInfo__AXEOT">
                    <?php $__currentLoopData = $chapterlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relatedEpisode_listItem__PNXFG">
                            <div class="lazyload-wrapper relatedEpisode_imgBox__05ArS image_imageLazyBox__ExNZG">
                                <div class="lazyload-wrapper relatedEpisode_imgBox__05ArS image_imageLazyBox__ExNZG"><a
                                        class="relatedEpisode_imgBox__05ArS image_imageBox__Mubn5 image_imageScaleBox__JFwzM"
                                        href="<?php echo e(route('dramas.video', [$data->bookId, $data->bookNameEn, $chapter->id . '_Episode-' . ($key + 1)])); ?>"><img
                                            alt="<?php echo e($data->bookName); ?>" loading="lazy" width="70" height="94"
                                            decoding="async" data-nimg="1" class="image_imageItem__IZeBT"
                                            src="<?php echo e($chapter->cover); ?>" style="color: transparent;"></a></div>
                            </div>
                            <a class="relatedEpisode_rightIntro__y7zZA"
                                href="<?php echo e(route('dramas.video', [$data->bookId, $data->bookNameEn, $chapter->id . '_Episode-' . ($key + 1)])); ?>"><span
                                    class="relatedEpisode_title__eygbR"><?php echo e($data->bookName); ?></span><span
                                    class="relatedEpisode_pageNum__W_ulP">EP. <?php echo e($key + 1); ?></span></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cf8820e207bda6b8.css')); ?>" data-n-p="" />
    <link rel="stylesheet" href="<?php echo e(asset('css/d8ca4c3c4ee5645f.css')); ?>" data-n-p="" />
    <link rel="stylesheet" href="<?php echo e(asset('css/7fc97ca489c15277.css')); ?>" data-n-p="" />
    <link rel="stylesheet" href="<?php echo e(asset('css/0131b3235f60f403.css')); ?>" data-n-p="" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        const playButton = document.querySelector('.pcEpisode_videoStart__IcAdF');
        const videoContainer = document.getElementById('videoContainer');
        const videoContainers = document.getElementById('videoContainers');
        const video = document.getElementById('video_pc_id');

        let videoContainersClicked = false;

        videoContainers.addEventListener('click', () => {
            videoContainersClicked = true;
        });

        playButton.addEventListener('click', () => {
            if (videoContainersClicked) {
                videoContainer.style.display = 'block';
                videoContainers.style.display = 'none';

                let currentPath = window.location.pathname;
                let pathArray = currentPath.split('/');
                let bookId = pathArray[1];
                let episodeFullId = pathArray[3];

                movieHistory[bookId] = movieHistory[bookId] || [];

                if (!movieHistory[bookId].includes(episodeFullId)) {
                    movieHistory[bookId].push(episodeFullId);
                    localStorage.setItem('movieHistory', JSON.stringify(movieHistory));
                }

                const episodeElement = document.getElementById(episodeFullId);
                if (episodeElement) {
                    episodeElement.classList.add('!bg-red-300');
                }

                video.play();
            } else {
                videoContainer.style.display = 'none';
                video.pause();
                video.currentTime = 0;
            }
        });

        window.addEventListener('load', () => {
            video.pause();
            video.currentTime = 0;
        });

        let movieHistory = JSON.parse(localStorage.getItem('movieHistory')) || {};
        const bookId = window.location.pathname.split('/')[1];
        if (movieHistory[bookId]) {
            movieHistory[bookId].forEach(element => {
                const episodeElement = document.getElementById(element);
                if (episodeElement) {
                    episodeElement.classList.add('!bg-red-300');
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zasieun/code/dramalele/resources/views/videod.blade.php ENDPATH**/ ?>