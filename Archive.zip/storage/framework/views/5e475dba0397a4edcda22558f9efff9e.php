<?php $__currentLoopData = $resp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('dramabox.show', [$data->bookId, $data->bookName])); ?>" class="block">
        <div class="aspect-[2/3] overflow-hidden rounded-lg bg-gray-800">
            <img src="<?php echo e($data->coverWap ?? $data->cover); ?>" class="w-full h-full object-cover" loading="lazy">
        </div>
        <p class="text-sm mt-2 text-white line-clamp-2">
            <?php echo e($data->bookName); ?>

        </p>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Users/zasieun/code/dramalele/resources/views/dramabox/partials/thumbnail.blade.php ENDPATH**/ ?>