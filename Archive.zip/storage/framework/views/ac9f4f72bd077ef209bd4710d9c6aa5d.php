<?php $__env->startSection('content'); ?>
    <header class="px-4 py-3 bg-black sticky top-0">
        <form action="<?php echo e(route('dramabox.search')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="text" name="keyword" placeholder="Search dramas..." value="<?php echo e(request('keyword')); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none" />
        </form>
    </header>

    <section class="px-4 mt-4 grid grid-cols-2 gap-4" id="movieListContainer"></section>
    <?php echo $__env->make('dramabox.partials.skeleton', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            const container = $("#movieListContainer")
            const skeleton = $("#skeleton-template").html()

            <?php if(request('keyword')): ?>
                // 1️⃣ Show skeletons immediately
                const SKELETON_COUNT = 10
                for (let i = 0; i < SKELETON_COUNT; i++) {
                    container.append(skeleton)
                }
            <?php endif; ?>

            $.ajax({
                url: "<?php echo e(route('dramabox.search')); ?>",
                data: {
                    keyword: "<?php echo e(request('keyword')); ?>"
                },
                method: "GET",
                success: function(response) {
                    container.empty() // remove skeletons
                    container.append(response)
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dramabox.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zasieun/code/dramalele/resources/views/dramabox/search.blade.php ENDPATH**/ ?>