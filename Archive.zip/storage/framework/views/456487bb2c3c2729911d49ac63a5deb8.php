<?php $__env->startSection('content'); ?>
    <main class="browse_browseBox__hZiZ_">
        <div class="browse_browseContent__hDbPH">
            <div class="browse_browseContent2__Ci_x5">
                <div class="FirstList_firstListBox__eN_W1">
                    <?php $__currentLoopData = $data->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $title_slug = strtolower(str_replace(' ', '-', $data->book_title));
                        ?>
                        <?php if($data->book_genre != 2): ?>
                            <div class="FirstList_itemBox__AfNNm">
                                <a class="FirstList_bookImage__ZbBGO image_imageBox__Mubn5"
                                    href="/reelshort/<?php echo e($data->book_id); ?>/<?php echo e($title_slug); ?>"><img
                                        alt="<?php echo e($data->book_title); ?>" loading="lazy" width="120" height="162"
                                        decoding="async" data-nimg="1" class="image_imageItem__IZeBT"
                                        style="color:transparent" src="<?php echo e($data->book_pic); ?>"></a>
                                <a class="FirstList_chapterCount__OyG6t"
                                    href="/reelshort/<?php echo e($data->book_id); ?>/<?php echo e($title_slug); ?>"><?php echo e($data->chapter_count); ?>

                                    Episodes</a>
                                <a class="FirstList_bookName__cULmf"
                                    href="/reelshort/<?php echo e($data->book_id); ?>/<?php echo e($title_slug); ?>"><?php echo e($data->book_title); ?></a>
                                <div class="FirstList_bookNameBox__LdUXf">
                                    <a class="FirstList_bookNameHover__f03t0"
                                        href="/reelshort/<?php echo e($data->book_id); ?>/<?php echo e($title_slug); ?>"><?php echo e($data->book_title); ?></a>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/ff991deaacf276d3.css')); ?>" data-n-p="" />
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zasieun/code/dramalele/resources/views/reelshort/index.blade.php ENDPATH**/ ?>