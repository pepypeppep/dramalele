<?php $__env->startSection('content'); ?>
    <?php if(str_contains(request()->userAgent(), 'Mobile') || str_contains(request()->userAgent(), 'Android')): ?>
        <?php echo $__env->make('videom', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('videod', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zasieun/code/dramalele/resources/views/video.blade.php ENDPATH**/ ?>